import './App.css';
import getPokemon from './pokedex'
import {useState, useEffect} from  'react';

function App() {
  const [pokemon, setPokemon] = useState({});

  useEffect(() => {
    
    const dataPokemon = async () => {
    const pokemonResponse = await getPokemon(1);
    console.log(pokemonResponse);
    setPokemon(pokemonResponse);
    }
    dataPokemon();
  }, []);
  return (
    <div className="App">
      {pokemon && (
        <img src={pokemon.sprites.other["official-artwork"].front_default} />
      )}
    </div>
  );
}

export default App;
